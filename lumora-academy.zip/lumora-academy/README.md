# Lumora Academy

Website pembelajaran sederhana yang dibuat dengan HTML, CSS, dan JavaScript.

## Menjalankan secara lokal
Buka `index.html` di browser.

## Publikasikan gratis dengan GitHub Pages
1. Buat repository bernama `lumora-academy` di GitHub.
2. Unggah `index.html` dan `README.md` ke repository.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main`, folder `/(root)`, lalu klik **Save**.
6. Tunggu beberapa menit. Situs akan tersedia di `https://USERNAME.github.io/lumora-academy/` (ganti `USERNAME` dengan username GitHub kamu).

Konten kelas dan kuis adalah contoh awal yang bisa kamu edit di `index.html`.
