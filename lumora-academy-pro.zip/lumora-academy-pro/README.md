# Lumora Academy

Website belajar statis untuk materi kuliah dan kuis interaktif. Dibuat dengan HTML, CSS, dan JavaScript tanpa proses build atau server.

## Fitur
- Materi kuliah: dasar Python, logika matematika, bilangan biner, pertidaksamaan, teknik belajar, dan menulis konten.
- Pencarian materi dan filter kategori.
- Dua paket kuis pilihan ganda dengan penilaian dan umpan balik.
- Progress kuis tersimpan di browser menggunakan `localStorage`.
- Tombol masuk demo tanpa kata sandi.
- Desain responsif untuk HP dan laptop.

> **Catatan:** login di sini hanya demo lokal. Tidak ada akun sungguhan, autentikasi server, atau sinkronisasi progres antarperangkat. Jangan gunakan kata sandi atau data pribadi.

## Publikasikan dengan GitHub Pages
1. Unduh dan ekstrak `lumora-academy-pro.zip`.
2. Masuk ke https://github.com dan buat repository baru bernama `lumora-academy`.
3. Pilih **Public**, lalu klik **Create repository**.
4. Pada halaman repository, pilih **Add file → Upload files**.
5. Unggah file `index.html` dan `README.md` dari folder yang sudah diekstrak (unggah file-nya, bukan folder ZIP).
6. Klik **Commit changes**.
7. Buka **Settings → Pages**.
8. Pada **Build and deployment**, pilih **Deploy from a branch**.
9. Pilih branch **main** dan folder **/(root)**, lalu klik **Save**.
10. Tunggu beberapa menit. Situs akan tersedia di:
   `https://USERNAME.github.io/lumora-academy/`
   Ganti `USERNAME` dengan username GitHub kamu.

## Mengedit isi
Buka `index.html`, lalu edit bagian daftar `lessons` untuk materi dan `quizzes` untuk soal kuis. Setelah menyimpan, unggah ulang `index.html` ke repository.
